/*
 *  Designed by: Beni Talwanga
    email: benttee7@gmail.com
    Date: 20/01/2025 
 */

using To_Do_List.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Adding services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddDbContext<TodoDbContext>(options =>
    options.UseSqlite("Data Source=TodoList.db"));
builder.Services.AddScoped<TodoService>();

var app = builder.Build();

// Ensuring the database is created
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<TodoDbContext>();
    dbContext.Database.EnsureCreated(); // Automatically creates the database and schema if not present
}

// Configuring the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
