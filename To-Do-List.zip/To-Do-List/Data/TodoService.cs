﻿/*
 *  Designed by: Beni Talwanga
    email: benttee7@gmail.com
    Date: 20/01/2025 
 */ 

using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using To_Do_List.Data;


public class TodoItem
{
    public int Id { get; set; }
    public string Title { get; set; }
    public bool IsCompleted { get; set; } = false;
}


public class TodoService
{
    private readonly TodoDbContext _dbContext;

    public TodoService(TodoDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<List<TodoItem>> GetAllAsync(string search = null)
    {
        if (string.IsNullOrWhiteSpace(search))
            return await _dbContext.TodoItems.ToListAsync();

        return await _dbContext.TodoItems
            .Where(t => t.Title.ToLower().Contains(search.ToLower()))
            .ToListAsync();
    }


    public async Task<TodoItem> AddAsync(string title)
    {
        var todoItem = new TodoItem { Title = title };
        _dbContext.TodoItems.Add(todoItem);
        await _dbContext.SaveChangesAsync();
        return todoItem;
    }



    public async Task<TodoItem> UpdateAsync(int id, string newTitle)
    {
        var todoItem = await _dbContext.TodoItems.FindAsync(id);
        if (todoItem == null)
            throw new Exception("Todo item not found.");

        todoItem.Title = newTitle;
        await _dbContext.SaveChangesAsync();
        return todoItem;
    }

    public async Task DeleteAsync(int id)
    {
        var todoItem = await _dbContext.TodoItems.FindAsync(id);
        if (todoItem == null)
            throw new Exception("Todo item not found.");

        _dbContext.TodoItems.Remove(todoItem);
        await _dbContext.SaveChangesAsync();
    }

    public async Task ToggleCompletedAsync(int id)
    {
        var todoItem = await _dbContext.TodoItems.FindAsync(id);
        if (todoItem == null)
            throw new Exception("Todo item not found.");

        todoItem.IsCompleted = !todoItem.IsCompleted;
        await _dbContext.SaveChangesAsync();
    }


}
